// Main.java
public class Main {
    public static void main(String[] args) {
        PaymentContext paymentContext = new PaymentContext();

        PaymentStrategy creditCardPayment = new CreditCardPayment("1111-2222-3333-4444", "Riddhi Agarwal");
        paymentContext.setPaymentStrategy(creditCardPayment);
        paymentContext.pay(350.75);

        PaymentStrategy payPalPayment = new PayPalPayment("riddhiagarwal654@gmail.com");
        paymentContext.setPaymentStrategy(payPalPayment);
        paymentContext.pay(250.00);
    }
}

