public class Main {
    public static void main(String[] args) {
        Image image1 = new ProxyImage("riddhi.jpg");
        Image image2 = new ProxyImage("riddhu.jpg");

        image1.display();
        System.out.println("");

        image1.display();
        System.out.println("");

        image2.display();
    }
}
