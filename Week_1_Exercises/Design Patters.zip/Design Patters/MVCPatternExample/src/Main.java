public class Main {
    public static void main(String[] args) {
        Student student = new Student("Riddhi Agarwal", "71", "A");
        StudentView view = new StudentView();
        StudentController controller = new StudentController(student, view);
        controller.updateView();
        controller.setStudentName("Ankita Pani");
        controller.setStudentGrade("B");
        controller.updateView();
    }
}
